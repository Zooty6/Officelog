package ReportFinder.Objects;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Represents a test result.
 */
public class TestResult implements Comparable {

    private String device;
    private String serialNr;
    private int totalResult;
    private String tester;
    private Date startedOn;
    private Date endedOn;
    private String remark;
    private List<Step> steps;

    public TestResult(String device, String serialNr, int totalResult, String tester, Date startedOn, Date endedOn, List<Step> steps) {
        this.device = device;
        this.serialNr = serialNr;
        this.totalResult = totalResult;
        this.tester = tester;
        this.startedOn = startedOn;
        this.endedOn = endedOn;
        this.remark = device + "#" + serialNr;
        this.steps = steps;
    }

    public String getDevice() {
        return device;
    }

    public String getSerialNr() {
        return serialNr;
    }

    public int getTotalResult() {
        return totalResult;
    }

    public String getTester() {
        return tester;
    }

    public Date getStartedOn() {
        return startedOn;
    }

    public Date getEndedOn() {
        return endedOn;
    }

    public String getRemark() {
        return remark;
    }

    public List<Step> getSteps() {
        return steps;
    }

    @Override
    public String toString() {
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. hh:mm:ss");
        return ft.format(endedOn);
    }

    @Override
    public int compareTo(Object o) {
        return this.endedOn.compareTo(((TestResult)o).getEndedOn());
    }
}

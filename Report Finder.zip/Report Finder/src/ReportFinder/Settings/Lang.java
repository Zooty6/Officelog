package ReportFinder.Settings;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

/**
 * This class stores the language library for the program,
 * and serves words to given labels.
 *
 * @author Kecskeméthy Zoltán
 */
public class Lang {
    private HashMap<String, String> Dictionary;
    private static Lang instance = null;
    private boolean loaded = false;

    /**
     * Singleton class, only one instance is created referred by the 'instance' variable.
     */
    private Lang(){
        Dictionary = new HashMap< >();
    }

    /**
     * @return The one instance of this class.
     */
    public static Lang getInstance() {
        if(instance==null)
            instance = new Lang();
        return instance;
    }

    /**
     * Loads the language file and stores all words found in it.
     * Also, sets the CurLanLoc to the loaded path in MetaData.
     *
     * @param path The path of the language file. If null, it loads the
     *             default language file defined in MetaData.
     */
    public void init(String path){
        if(path == null)
            //loading default language file
            path = MetaData.getInstance().getDefLanLoc();

        try (BufferedReader br = new BufferedReader( new InputStreamReader(
                new FileInputStream(path), "UTF8"))) {

            String Line;
            while ((Line = br.readLine()) != null) {
                String[] SplitLine = Line.split("\t");            //Split by tab
                if(SplitLine.length == 2){                              //Handles lines with exactly one tab
                    Dictionary.put(SplitLine[0],SplitLine[1]);         //Loads the label and the string
                }
            }
            loaded = true;

            if(!path.equals(MetaData.getInstance().getCurLanLoc()))
                MetaData.getInstance().setCurLanLoc(path);

        //If failed to load, tries to load the default language file.
        //If the default language file failed to load, terminates.
        } catch (IOException e) {
            if(path.equals(MetaData.getInstance().getDefLanLoc())) {
                System.err.println("Couldn't load language file.");
            }  else{
                init(null); //Loading default language file.
            }
        }
    }

    public boolean isLoaded() {
        return loaded;
    }

    /**
     * Returns one string from the vocabulary.
     *
     * @param label The label we search with.
     *
     * @return The string behind that label. Returns ull if parameter label can't be found.
     */
    public String getString(String label){
        return Dictionary.get(label);
    }
}

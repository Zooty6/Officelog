package ReportFinder;

import ReportFinder.GUI.MWController;
import ReportFinder.Settings.Lang;
import ReportFinder.Settings.MetaData;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.awt.*;

/**
 * Entry point for the program
 *
 * @author Kecskeméthy Zoltán
 */
public class Main extends Application {

    /**
     * Entry point.
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Initializes the program. Loads config parameters from settings.ini and loads the language file.
     *
     * @throws Exception
     */
    @Override
    public void init() throws Exception {
        MetaData.getInstance().init();                                          //Loads settings.ini.
        Lang.getInstance().init(MetaData.getInstance().getCurLanLoc());         //Loads language file.
    }

    /**
     * Starts the application.
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            //System.out.println(XMLReader.createTestResult(MetaData.getInstance().getXMLLoc() + "II40820$1110#3517190001.xml"));
            //Desktop.getDesktop().open(new File(MetaData.getInstance().getPDFLoc() + "RLV3-NIO_1128.pdf"));

            //PDFOpener.open("");
            //If the language file failed to load, the program terminates.
            if (!Lang.getInstance().isLoaded()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Couldn't load the language file! The program will close.");
                alert.showAndWait();
                System.exit(1);
            }

            //Building up the GUI based on the FXML file..
            Parent root = FXMLLoader.load(getClass().getResource("GUI/MainWindow.fxml"));
            primaryStage.setTitle(Lang.getInstance().getString("Title"));
            primaryStage.setScene(new Scene(root, MetaData.WINDOWWIDTH, MetaData.WINDOWHEIGHT));
            primaryStage.setMinWidth(600);
            primaryStage.setMinHeight(450);
            //The banner at the top is a rectangle, we always want it as wide as the scene..
            primaryStage.widthProperty().addListener(((obs, oldVal, newVal) ->{
                if(!primaryStage.maximizedProperty().get())
                    MWController.instance.resizeBanner(primaryStage.getScene().getWidth());}));
            primaryStage.maximizedProperty().addListener((observable, oldValue, newValue) ->
                    MWController.instance.resizeBanner(Toolkit.getDefaultToolkit().getScreenSize().getWidth()));
            primaryStage.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(Lang.getInstance().getString("ErrorTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Lang.getInstance().getString("DefErr"));
            alert.showAndWait();
            //e.printStackTrace();
            System.exit(2);
        }
    }
}

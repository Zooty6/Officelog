package ReportFinder;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Entry point for the program
 *
 * @author Kecskeméthy Zoltán
 */
public class Main extends Application {

    /**
     * Entry point.
     *
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Initializes the program. Loads config parameters from settings.ini and loads the language file.
     *
     * @throws Exception
     */
    @Override
    public void init() throws Exception {
        MetaData.getInstance().init();                                          //Loads settings.ini.
        Lang.getInstance().init(MetaData.getInstance().getCurLanLoc());         //Loads language file.
    }

    /**
     * Starts the application.
     *
     * @param primaryStage
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception{
        //System.out.println(XMLReader.createTestResult(MetaData.getInstance().getXMLLoc() + "1352221010#3517020003.xml"));

        //Building up the GUI based on the FXML file..
        Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
        primaryStage.setTitle(Lang.getInstance().getString("Title"));
        primaryStage.setScene(new Scene(root, MetaData.WINDOWWIDTH, MetaData.WINDOWHEIGHT));
        primaryStage.setMinWidth(400);
        primaryStage.setMinHeight(500);
        //The banner at the top is a rectangle, we always want it as wide as the scene..
        primaryStage.widthProperty().addListener(((obs, oldVal, newVal) ->
                MWController.instance.resizeBanner(primaryStage.getScene().getWidth())));
        primaryStage.show();
    }

}

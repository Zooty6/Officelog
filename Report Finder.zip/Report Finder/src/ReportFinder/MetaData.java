package ReportFinder;

import javafx.application.Platform;
import javafx.scene.control.Alert;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

/**
 * Stores meta data for the program. Feeds from settings.ini.
 * Singleton class.
 *
 * @author Kecskeméthy Zoltán
 */
public class MetaData {

    public static final int WINDOWWIDTH = 400;
    public static final int WINDOWHEIGHT = 500;
    private static MetaData instance = null;
    private String DefLanLoc = "Lang\\En_def.lan";
    private String CurLanLoc = null;
    private String XMLLoc = "\\\\buds0090\\abt\\ABT-BC\\00-Test Reports\\Prod_HV_Test\\";

    /**
     * Singleton class, only one instance is created, referred by the 'instance' variable.
     */
    private MetaData() {}

    /**
     * @return The one instance of this class.
     */
    public static MetaData getInstance() {
        if(instance == null)
            instance = new MetaData();
        return instance;
    }

    public String getDefLanLoc() {
        return DefLanLoc;
    }

    public String getCurLanLoc() {
        return CurLanLoc;
    }

    public String getXMLLoc() {
        return XMLLoc;
    }

    /**
     * Loads settings.ini, and stores all known attributes from it.
     */
    public void init() {
        try (BufferedReader br = new BufferedReader(new FileReader("settings.ini"))) {
            String Line;

            //Check every lines and search for known words..
            while ((Line = br.readLine()) != null) {
                try{
                String[] SplitLine = Line.split("\t");            //Split by tab
                switch (SplitLine[0].toLowerCase()) {                   //Searching for all known parameters
                    case "deflang":                                     //and stores values..
                        DefLanLoc = SplitLine[1];
                        break;
                    case "curlang":
                        CurLanLoc = SplitLine[1];
                        break;
                    case "xmlloc":
                        XMLLoc = SplitLine[1];
                        //Fixing the path if it doesn't end with "\".
                        XMLLoc += XMLLoc.charAt(XMLLoc.length()-1)!='\\'?"\\":"";
                        //System.out.println(XMLLoc);
                        break;
                    default:
                        System.err.println("Unknown line: " + Line);

                }
                }catch (Exception e){
                    System.err.println("invalid format in settings.ini: " + Line);
                    }
            }
        }catch (IOException e) {
            System.err.println("Can't load settings.ini.");
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Couldn't load settings.ini!");
                //alert.showAndWait(); //Do we want to report the user?
            }
            );

        }
    }

    /**
     * Sets the current location, and stores it in the settings.ini file.
     * Should call this every time the language is changed by the user.
     *
     * @param curLanLoc location of the current language file.
     */
    public void setCurLanLoc(String curLanLoc) {
        CurLanLoc = curLanLoc;
        StringBuilder text= new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader("settings.ini"))) {
            String line;

            while ((line = br.readLine()) != null) {                    //Reads everything and stores all lines in the
                                                                        //text variable. If we find the line that starts
                if(line.split("\t")[0].equals("CurLang")){       //with "CurLang", we change the line.
                    text.append("CurLang" + "\t").append(CurLanLoc);
                }else {
                    text.append(line).append(System.lineSeparator());
                }
                //System.out.println(text);
            }
            try(FileOutputStream os = new FileOutputStream("settings.ini")) {
                os.write(text.toString().toString().getBytes());        //Writes the new "text" variable's value to
            }catch (IOException e){                                     //settings.ini.
                System.err.println("Can't update settings.ini!");
            }
        }catch (IOException e) {
            System.err.println("Can't update settings.ini!");
        }
    }
}

package ReportFinder;

import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * Class for opening a file in KMPprfprt.
 */
public class PDFOpener {
    private PDFOpener(){}

    /**
     * Opening report(s) for the parameter item.
     *
     * @param name String of the test item we are searching. Format: Device#SerialNr
     * @return True if report is found.
     */
    public static Boolean open(String name) {
        boolean found = false;
        name = name.replace('/', '%');
        String[] SplitName = name.split("#");
        if (SplitName.length == 2) {
            File LangFolder = new File(MetaData.getInstance().getPDFLoc());
            File[] listOfFiles = LangFolder.listFiles();
            //Checking all files..
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    System.out.println(file.getName());
                    //Filtering files to open only what we are looking for.
                    if(file.getName().contains("$11" + SplitName[0])
                            && file.getName().contains("$12" + SplitName[1]))
                        try {
                            Desktop.getDesktop().open(file);
                            found = true;
                        } catch (IOException e) {
                            System.err.println("couldn't open " + file.getName());
                        }
                }
            }
        }
        return found;
    }
}

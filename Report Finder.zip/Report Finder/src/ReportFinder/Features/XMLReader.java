package ReportFinder.Features;

import ReportFinder.Objects.Step;
import ReportFinder.Objects.TestResult;
import ReportFinder.Settings.MetaData;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class for reading an XML of a report.
 *
 * @author Kecskeméthy Zoltán
 */
public class XMLReader {

    /**
     * Don't let anyone instantiate this class.
     */
    private XMLReader() {}

    /**
     * Opens an XML file and loads its content into a list of TestResults. The steps of each test is not represented yet.
     *
     * @param name The name of the product.
     *
     * @return A list of test results parsed from the XML file.
     * @throws ParserConfigurationException
     * @throws XPathExpressionException
     * @throws IOException
     * @throws SAXException
     */
    public static List<TestResult> createTestResult(String name) throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        //Swap special characters in the text as they are represented in the actual file.
        name = name.replace('/','$');
        String filepath = MetaData.getInstance().getXMLLoc() + name + ".xml";
        List<TestResult> testResults = new ArrayList<>();
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        //documentBuilderFactory.setNamespaceAware(true);
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();

        Document document = documentBuilder.parse(new FileInputStream(filepath));

        XPathExpression test = xPath.compile("/SPS-RESULTS/TEST-RESULTS");

        NodeList results = (NodeList) test.evaluate(document, XPathConstants.NODESET);

        for (int i = 0; i < results.getLength(); i++) {
            Node item = results.item(i);
            //NamedNodeMap namedAttributes = item.getAttributes();
            //System.out.println(namedAttributes.getNamedItem("UserTester").getTextContent());
            //System.out.println(item);
            NodeList attributes = item.getChildNodes();
            try {
                //System.out.println(getTestResultFromNode(attributes));
                testResults.add(getTestResultFromNode(attributes));
            } catch (Exception e) {
                System.err.println("Couldn't parse the header of a test result!");
            }

            //System.out.println(attributes.getNamedItem("UserTester").getTextContent());
            //System.out.println(item.getFirstChild().getNodeValue());
        }
            return testResults;
    }

    /**
     * Creates a TestResult from and XML NodeList. Does not handle Steps (yet).
     *
     * @param attributes The NodeList contains the header of a test result.
     * @return A TestResult loaded with all the data from the NodeList.
     * @throws ParseException If the XML file is badly formatted.
     */
    private static TestResult getTestResultFromNode(NodeList attributes) throws ParseException, XPathExpressionException {
        String device = null;
        String serialNr = null;
        int totalResult = -1;
        String tester = null;
        Date startedOn = null;
        Date endedOn = null;
        List<Step> steps = new ArrayList<>();

        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. hh:mm:ss");

        for (int i = 0; i < attributes.getLength(); i++ ) {
            Node nod = attributes.item(i);
            if(nod.getNodeType() == Node.ELEMENT_NODE && !nod.getNodeName().contains("STEP")) {
                //System.out.println(nod.getNodeName() + ": " + nod.getTextContent());
                switch (nod.getNodeName()){
                    case "Device":
                        device = nod.getTextContent();
                        break;
                    case "SerialNr":
                        serialNr = nod.getTextContent();
                        break;
                    case "TotalResult":
                        totalResult = Integer.parseInt(nod.getTextContent());
                        break;
                    case "UserTester":
                        tester = nod.getTextContent();
                        break;
                    case "StartDate":
                        startedOn = ft.parse(nod.getTextContent());
                        break;
                    case "EndDate":
                        endedOn = ft.parse(nod.getTextContent());
                        break;
                }
            }

            if(nod.getNodeType() == Node.ELEMENT_NODE && nod.getNodeName().contains("STEP"))
                steps.add(getStepsFromNode(nod));


        }

        return new TestResult(device, serialNr, totalResult, tester, startedOn, endedOn, steps);
    }

    private static Step getStepsFromNode(Node nod) {
        //System.out.println(nod.getChildNodes().item(2).getNodeName());
        Step step = new Step();
        for (int i = 0; i < nod.getChildNodes().getLength(); i++)
            if(nod.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE)
                step.getStep().append(nod.getChildNodes().item(i).getNodeName() + ": " + nod.getChildNodes().item(i).getTextContent())
                        .append(System.lineSeparator());
        return step;
    }

}

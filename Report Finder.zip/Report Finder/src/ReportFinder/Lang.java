package ReportFinder;

import javafx.application.Platform;
import javafx.scene.control.Alert;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

/**
 * This class stores the language library for the program,
 * and serves words to given labels.
 *
 * @author Kecskeméthy Zoltán
 */
public class Lang {
    private HashMap<String, String> LangStrings;
    private static Lang instance = null;

    /**
     * Singleton class, only one instance is created referred by the 'instance' variable.
     */
    private Lang(){
        LangStrings = new HashMap< >();
    }

    /**
     *
     * @return The one instance of this class.
     */
    public static Lang getInstance() {
        if(instance==null)
            instance = new Lang();
        return instance;
    }

    /**
     * Loads the language file and stores all words found in it.
     * Also, sets the CurLanLoc to the loaded path in MetaData.
     *
     * @param path The path of the language file. If null, it loads the
     *             default language file defined in MetaData.
     */
    public void init(String path){
        if(path == null)
            //loading default language file
            path = MetaData.getInstance().getDefLanLoc();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String Line;

            while ((Line = br.readLine()) != null) {
                String[] SplitLine = Line.split("\t");            //Split by tab
                if(SplitLine.length == 2){                              //Handles lines with exactly one tab
                    LangStrings.put(SplitLine[0],SplitLine[1]);         //Loads the label and the string
                }
            }
            MetaData.getInstance().setCurLanLoc(path);

        //If failed to load, tries to load the default language file.
        //If the default language file failed to load, terminates.
        } catch (IOException e) {
            if(path.equals(MetaData.getInstance().getDefLanLoc())) {
                System.err.println("Couldn't load language file. Program will terminate.");
                Platform.runLater(() -> {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setHeaderText(null);
                            alert.setContentText("Couldn't load the language file! The program will close.");
                            alert.showAndWait();
                        }
                );
                System.exit(1);
            }  else{
                init(null);
            }
        }
    }

    /**
     * Returns one string from the vocabulary.
     *
     * @param label The label we search with.
     *
     * @return The string behind that label. Returns ull if parameter label can't be found.
     */
    public String getString(String label){
        return LangStrings.get(label);
    }
}

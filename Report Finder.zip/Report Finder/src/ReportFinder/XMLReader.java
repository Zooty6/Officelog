package ReportFinder;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Kecskeméthy Zoltán
 */
public class XMLReader {
    private XMLReader() {}

    /**
     * Opens an XML file and parses its content into a list of TestResults. The steps of each tests is not represented.
     *
     * @param filepath The location of the XML file.
     *
     * @return A list of test results parsed from the XML file.
     * @throws ParserConfigurationException
     * @throws XPathExpressionException
     * @throws IOException
     * @throws SAXException
     */
    public static List<TestResult> createTestResult(String filepath) throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        List<TestResult> testResults = new ArrayList<>();
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        //documentBuilderFactory.setNamespaceAware(true);
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();

        Document document = documentBuilder.parse(new FileInputStream(filepath));

        XPathExpression test = xPath.compile("/SPS-RESULTS/TEST-RESULTS");

        NodeList results = (NodeList) test.evaluate(document, XPathConstants.NODESET);


        for (int i = 0; i < results.getLength(); i++) {
            Node item = results.item(i);
            //NamedNodeMap namedAttributes = item.getAttributes();
            //System.out.println(namedAttributes.getNamedItem("UserTester").getTextContent());
            //System.out.println(item);
            NodeList attributes = item.getChildNodes();
            try {
                //System.out.println(getTestResultFromNode(attributes));
                testResults.add(getTestResultFromNode(attributes));
            } catch (Exception e) {
                System.err.println("Couldn't parse the header of a test result!");
            }

            //System.out.println(attributes.getNamedItem("UserTester").getTextContent());


            //System.out.println(item.getFirstChild().getNodeValue());
        }
            return testResults;
    }

    /**
     * Creates a TestResult from and XML NodeList. Does not handle Steps (yet).
     *
     * @param attributes The NodeList contains the header of a test result.
     * @return A TestResult loaded with all the data from the NodeList.
     * @throws ParseException If the XML file is badly formatted.
     */
    private static TestResult getTestResultFromNode(NodeList attributes) throws ParseException {
        String device = null;
        String serialNr = null;
        int totalResult = -1;
        String tester = null;
        Date startedOn = null;
        Date endedOn = null;

        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. hh:mm:ss");

        for (int i = 0; i < attributes.getLength(); i++ ) {
            Node nod = attributes.item(i);
            if(nod.getNodeType() == Node.ELEMENT_NODE && !nod.getNodeName().contains("STEP")) {
                //System.out.println(nod.getNodeName() + ": " + nod.getTextContent());
                switch (nod.getNodeName()){
                    case "Device":
                        device = nod.getTextContent();
                        break;
                    case "SerialNr":
                        serialNr = nod.getTextContent();
                        break;
                    case "TotalResult":
                        totalResult = Integer.parseInt(nod.getTextContent());
                        break;
                    case "UserTester":
                        tester = nod.getTextContent();
                        break;
                    case "StartDate":
                        startedOn = ft.parse(nod.getTextContent());
                        break;
                    case "EndDate":
                        endedOn = ft.parse(nod.getTextContent());
                        break;
                }
            }
        }
        return new TestResult(device, serialNr, totalResult, tester, startedOn, endedOn);
    }

}

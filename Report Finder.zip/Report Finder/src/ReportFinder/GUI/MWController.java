package ReportFinder.GUI;

import ReportFinder.Features.PDFOpener;
import ReportFinder.Features.XMLReader;
import ReportFinder.Objects.Step;
import ReportFinder.Objects.TestResult;
import ReportFinder.Settings.Lang;
import ReportFinder.Settings.MetaData;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutionException;

public class MWController implements Initializable {

    public static MWController instance;

    @FXML
    private AnchorPane apPane;
    @FXML
    private ChoiceBox<TestResult> cbReports;
    @FXML
    private Label lbCounter;
    @FXML
    private Label lbDeviceNumber;
    @FXML
    private Label lbSerial;
    @FXML
    private Label lbStartDate;
    @FXML
    private Button btnOk;
    @FXML
    private Label lbEndDate;
    @FXML
    private Label lbResult;
    @FXML
    private Label lbTester;
    @FXML
    private TextField tfSerial;
    @FXML
    private Rectangle rtBanner;
    @FXML
    private Label lbStart;
    @FXML
    private Label lbSerialNumber;
    @FXML
    private Label lbTesterName;
    @FXML
    private Label lbResultValue;
    @FXML
    private Label lbEnd;
    @FXML
    private Label lbDevice;
    @FXML
    private TextArea taSteps;
    @FXML
    private Menu meSelLang;
    @FXML
    private Menu meOptions;
    @FXML
    private RadioMenuItem rmPdf;

    private Dialog<Void> dialog;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        instance = this;
        rmPdf.setSelected(MetaData.getInstance().isPdf());
        refreshLabels();
        populateLanguageMenu();
        //Adding listener for cbReports. Every time we select a new report, we load it.
        cbReports.getSelectionModel().selectedIndexProperty().addListener((observableValue, number, number2) ->{
            if (observableValue.getValue().intValue() > -1)
                displayReport(cbReports.getItems().get(observableValue.getValue().intValue()));});
    }

    /**
     * Sets every label on the GUI based on the loaded language.
     */
    private void refreshLabels() {
        btnOk.setText(Lang.getInstance().getString("SearchString"));
        lbDevice.setText(Lang.getInstance().getString("DeviceString") + ":");
        lbSerial.setText(Lang.getInstance().getString("SerialString") + ":");
        lbResult.setText(Lang.getInstance().getString("TotResultString") + ":");
        lbTester.setText(Lang.getInstance().getString("TesterString") + ":");
        lbStart.setText(Lang.getInstance().getString("StartString") + ":");
        lbEnd.setText(Lang.getInstance().getString("EndString") + ":");
        meOptions.setText(Lang.getInstance().getString("OptionString"));
        meSelLang.setText(Lang.getInstance().getString("SelLangString"));
        rmPdf.setText(Lang.getInstance().getString("PDFString"));
        lbCounter.setText(Lang.getInstance().getString("CountString") + ": " + cbReports.getItems().size());
        if(apPane.getScene() != null)
            ((Stage)(apPane.getScene().getWindow())).setTitle(Lang.getInstance().getString("Title"));
    }

    /**
     * Displays a loading dialog. Not implemented..
     */
    private void loadingDialog(){
        //source: https://stackoverflow.com/questions/33457844/javafx-indeterminate-progress-dialog-overlay
        dialog = new Dialog<>();
        dialog.initModality(Modality.NONE);
        dialog.initOwner(apPane.getScene().getWindow());
        dialog.initStyle(StageStyle.TRANSPARENT);
        dialog.getDialogPane().setMaxWidth(75);
        Label loader = new Label("LOADING");
        loader.setContentDisplay(ContentDisplay.CENTER);
        loader.setGraphic(new ProgressIndicator());
        dialog.getDialogPane().setGraphic(loader);
        DropShadow ds = new DropShadow();
        ds.setOffsetX(1.3); ds.setOffsetY(1.3);
        ds.setColor(Color.DARKGRAY);
        dialog.getDialogPane().setEffect(ds);
        dialog.show();

    }

    /**
     * Closes the loading dialog.
     */
    private void closeLoadingDialog(){
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL);
        dialog.close();
    }

    /**
     * Action of the Search button. Searches for a report with the given name..
     *
     * @param event caller
     */
    @FXML
    void btnAction(ActionEvent event) throws ExecutionException, InterruptedException {
        if(!tfSerial.getText().equals("")) {
            List<TestResult> testResults;
            String name = tfSerial.getText();

            //Cutting the '#' from the end of the name since the barcode reader might put it there.
            if (name.charAt(name.length() - 1) == '#')
                name = name.substring(0, name.length() - 1);

            try {
                testResults = XMLReader.createTestResult(name);
                //loadingDialog();

                //Sorting the collection by endDate. Oldest report is the first.
                Collections.sort(testResults);

                //Loading test results into cbReports.
                cbReports.setItems(FXCollections.observableArrayList(testResults));
                cbReports.getSelectionModel().selectLast();
                cbReports.setVisible(true);
                //Loading the most recent report. (Last one in the list.)
                displayReport(testResults.get(testResults.size() - 1));
                lbCounter.setText(Lang.getInstance().getString("CountString") + ": " + cbReports.getItems().size());
                //Giving the focus back the the text field.
                tfSerial.requestFocus();
            } catch (XPathExpressionException | ParserConfigurationException | IOException | SAXException e) {
                System.err.println("Couldn't open XML file.");
                Boolean pdfFound = false;

                //<editor-fold desc="Not implemented multithreading">
                /*final String finalName = name;
                RunnableFuture f = new FutureTask((Callable<Boolean>) () -> PDFOpener.open(finalName));
                Thread pdfThread = new Thread(f);*/
                //</editor-fold>

                //We search for report(s) in KMPprfprt if the user selected rmPdf.
                if (rmPdf.isSelected()) {
                    //<editor-fold desc="Not implemented multithreading">
                    /*if(pdfThread.isAlive())
                        pdfThread.stop();
                    pdfThread.start();*/
                    //</editor-fold>
                    pdfFound = PDFOpener.open(name);
                }

                //Alerting user if no result is found.
                if (!pdfFound) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle(Lang.getInstance().getString("InfoTitle"));
                    alert.setHeaderText(Lang.getInstance().getString("NoRepSubTitle"));
                    alert.setContentText(Lang.getInstance().getString("NoRep") + ": " + name);
                    alert.showAndWait();
                }
                tfSerial.requestFocus();
            } finally {
               // closeLoadingDialog();
            }
        }
    }

    /**
     * Displays one report on the GUI.
     *
     * @param testResult the report we want to display.
     */
    private void displayReport(TestResult testResult) {

        //Feeding components with data..
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. hh:mm:ss");
        lbDeviceNumber.setText(testResult.getDevice());
        lbSerialNumber.setText(testResult.getSerialNr());
        // If we have a string for that result in the Lang file, we display that, else just the number.
        lbResultValue.setText(Lang.getInstance().getString("Result" + testResult.getTotalResult()) == null?
                "" + testResult.getTotalResult(): Lang.getInstance().getString("Result" + testResult.getTotalResult()));
        lbTesterName.setText(testResult.getTester());
        lbStartDate.setText(ft.format(testResult.getStartedOn()));
        lbEndDate.setText(ft.format(testResult.getEndedOn()));
        taSteps.setText("");
        for (Step step : testResult.getSteps()) {
            taSteps.setText(taSteps.getText() + step.toString() + "--------------------------"
                    + System.lineSeparator() + System.lineSeparator());
        }

        //Making those components visible if needed.
        if(!lbDevice.isVisible()) {
            lbDevice.setVisible(true);
            lbDeviceNumber.setVisible(true);
            lbSerial.setVisible(true);
            lbSerialNumber.setVisible(true);
            lbResult.setVisible(true);
            lbResultValue.setVisible(true);
            lbTester.setVisible(true);
            lbTesterName.setVisible(true);
            lbStart.setVisible(true);
            lbStartDate.setVisible(true);
            lbEnd.setVisible(true);
            lbEndDate.setVisible(true);
            lbCounter.setVisible(true);
            taSteps.setVisible(true);
        }
    }

    /**
     * Loads the selected language.
     *
     * @param event caller
     */
    void onLanguageLoad(ActionEvent event){
        Lang.getInstance().init("Lang\\"+((MenuItem) (event.getSource())).getText()+".lan");
        refreshLabels();
        meOptions.hide();
    }

    @FXML
    void onPdfClick(ActionEvent event){
        MetaData.getInstance().setPdf(rmPdf.isSelected());
    }

    /**
     * Every time we click on the menu bar, we load all the language files to it.
     * Doesn't work at the moment, we only load it on initialize()!
     *
     * @param event
     */
    @FXML
    void onOptions(ActionEvent event) {
        populateLanguageMenu();
    }

    /**
     * The "select language" menu item must be populated dynamically with the content of the Lang folder.
     * This method only cares about *.lan files, loads their names, and replaces the items in meSelLang.
     */
    private void populateLanguageMenu() {
        File LangFolder = new File("Lang");
        File[] listOfFiles = LangFolder.listFiles();
        if (listOfFiles.length > 0)
            //If we found something, we clear all items, and replace them with new ones.
            meSelLang.getItems().clear();
        for (int i = 0; i < listOfFiles.length; i++) {
            MenuItem languagefile = new MenuItem();
            //Trimming the extension of the file name.
            String filename = "";
            String[] nameparts = listOfFiles[i].getName().split("\\.");
            if(nameparts[nameparts.length-1].equals("lan")){  //We only care about .lan files.
                for (int i1 = 0; i1 < nameparts.length-1; i1++)
                    //We replace every dots, except the last one.
                    filename += i1 == nameparts.length - 2 ? nameparts[i1] : nameparts[i1] + '.';
                languagefile.setText(filename);
                languagefile.setOnAction((f) -> onLanguageLoad(f));
                meSelLang.getItems().add(languagefile);
            }
        }
    }

    /**
     * Resize the banner rectangle's width to parameter value.
     * It gets called every time the main scene is resized.
     *
     * @param width the new width of the banner.
     */
    public void resizeBanner(double width){
        rtBanner.setWidth(width);
    }

}

package ReportFinder;

/**
 * Represents a Step in a test lazily.
 * Normally every attribute of a step should be represented here individually..
 */
public class Step {
    private StringBuilder step;

    public Step() {
        this.step = new StringBuilder();
    }

    public StringBuilder getStep() {
        return step;
    }

    @Override
    public String toString() {
        return step.toString();
    }
}

package ReportFinder.Objects;

import ReportFinder.Settings.Lang;

import java.text.SimpleDateFormat;

/**
 * This class is used to populate a TableView with items.
 */
public class TestResultForTable {
    private String tester;
    private String dateString;
    private String serialNr;
    private int totalResult = 0;
    private String device;
    private String pdfLoc;


    public TestResultForTable(String device, String serialNr, String pdfLoc) {
        this.device = device;
        this.serialNr = serialNr;
        this.pdfLoc = pdfLoc;
        totalResult = 0;
        dateString = null;
        tester = null;
    }

    public TestResultForTable(TestResult tr){
        tester = tr.getTester();
        serialNr = tr.getSerialNr();
        totalResult = tr.getTotalResult();
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. HH:mm:ss");
        dateString = ft.format(tr.getEndedOn());
        device = tr.getDevice();
        pdfLoc = null;
    }

    public String getPdfLoc() {
        return pdfLoc;
    }

    public String getTester() {
        return tester;
    }

    public String getDateString() {
        return dateString;
    }

    public String getSerialNr() {
        return serialNr;
    }

    public String getDevice() {
        return device;
    }

    public String getTotalResult() {
        return Lang.getInstance().getString("Result" + totalResult) == null ?
                "" + totalResult : Lang.getInstance().getString("Result" + totalResult);
    }
}

package ReportFinder.Features;

import ReportFinder.GUI.MWController;
import ReportFinder.GUI.SerialsTableController;
import ReportFinder.Objects.Step;
import ReportFinder.Objects.TestResult;
import ReportFinder.Settings.Lang;
import ReportFinder.Settings.MetaData;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class for reading an XML of a report.
 *
 * @author Kecskeméthy Zoltán
 */
public class XMLReader {
    //Test: II40820/1110#3517190001II40820/1110#3517190001

    /**
     * Don't let anyone instantiate this class.
     */
    private XMLReader() {}

    /**
     * Opens an XML file and loads its content into a list of TestResults.
     *
     * @param name The name of the product.
     *
     * @return A list of test results parsed from the XML file.
     */
    public static List<TestResult> loadTestResult(String name) throws ParserConfigurationException, XPathExpressionException, IOException, SAXException {
        //Swap special characters in the text as they are represented in the actual file.
        name = name.replace('/','$');
        String filepath = MetaData.getInstance().getXMLLoc() + name + ".xml";
        List<TestResult> testResults = new ArrayList<>();
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        //documentBuilderFactory.setNamespaceAware(true);
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();

        Document document = null;
        try {
            document = documentBuilder.parse(new FileInputStream(filepath));
        }catch (SAXParseException e){
            System.err.println("Can't open " + filepath + "!");
            System.err.println(e.getMessage());

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(Lang.getInstance().getString("CantOpen") + " " + filepath);
            alert.setContentText(e.getMessage());

            //source:
            //https://stackoverflow.com/questions/38799220/javafx-how-to-bring-dialog-alert-to-the-front-of-the-screen
            DialogPane root = alert.getDialogPane();
            Stage dialogStage = new Stage(StageStyle.UNIFIED);
            dialogStage.setTitle(Lang.getInstance().getString("ErrorTitle"));
            for (ButtonType buttonType : root.getButtonTypes()) {
                ButtonBase button = (ButtonBase) root.lookupButton(buttonType);
                button.setOnAction(evt -> {
                    root.setUserData(buttonType);
                    dialogStage.close();
                });
            }
            root.getScene().setRoot(new Group());
            root.setPadding(new Insets(10, 0, 0, 0));
            Scene scene = new Scene(root);
            dialogStage.getIcons().add(new Image("file:img/logo.png"));
            dialogStage.setScene(scene);
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setAlwaysOnTop(true);
            dialogStage.setResizable(false);
            dialogStage.show();
        }

        XPathExpression test = xPath.compile("/SPS-RESULTS/TEST-RESULTS");

        NodeList results = (NodeList) test.evaluate(document, XPathConstants.NODESET);

        for (int i = 0; i < results.getLength(); i++) {
            Node item = results.item(i);
            //NamedNodeMap namedAttributes = item.getAttributes();
            //System.out.println(namedAttributes.getNamedItem("UserTester").getTextContent());
            //System.out.println(item);
            NodeList attributes = item.getChildNodes();
            try {
                //System.out.println(getTestResultFromNode(attributes));
                testResults.add(getTestResultFromNode(attributes));
            } catch (Exception e) {
                System.err.println("Couldn't parse the header of a test result!");
            }

            //System.out.println(attributes.getNamedItem("UserTester").getTextContent());
            //System.out.println(item.getFirstChild().getNodeValue());
        }
            return testResults;
    }

    /**
     * Loads all reports for a specific device number, and displays them on a list.
     *
     * @param root Parent window.
     */
    public static void loadSerials(Parent root) {
        //name = name.replace('/','$');
        //SerialsTableController.setName(name); //This does not work. Name is initialized too late..
        Stage stage = new Stage();
        //Adding event for pressing ESCAPE. (Closing the window.)
        stage.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            if(key.getCode() == KeyCode.ESCAPE)
                stage.close();
        });
        stage.setTitle(Lang.getInstance().getString("Title") + " " + MetaData.VERSION);
        stage.setScene(new Scene(root, MetaData.WINDOWWIDTH-50, MetaData.WINDOWHEIGHT));
        stage.initOwner(MWController.instance.getWindow());
        stage.initModality(Modality.WINDOW_MODAL);
        stage.getIcons().add(new Image("file:img/logo.png"));
        stage.setOnHidden(event -> {
            if (!MetaData.getInstance().isPdf())
                MWController.instance.refreshLabels();}); //For the label of the search button.
        stage.setMinWidth(520);
        stage.setMinHeight(450);
        stage.setWidth(520);
        stage.resizableProperty().setValue(false);
        stage.setTitle(stage.getTitle() + " (" + MWController.instance.getText().toUpperCase() + ')');
        stage.setOnHidden(event -> {if(SerialsTableController.pdfThread != null)
            SerialsTableController.pdfThread.stop();
        });
        stage.showAndWait();
    }

    /**
     * Creates a TestResult from and XML NodeList.
     *
     * @param attributes The NodeList contains the header of a test result.
     * @return A TestResult loaded with all the data from the NodeList.
     * @throws ParseException If the XML file is badly formatted.
     */
    private static TestResult getTestResultFromNode(NodeList attributes) throws ParseException, XPathExpressionException {
        String device = null;
        String serialNr = null;
        int totalResult = -1;
        String tester = null;
        Date startedOn = null;
        Date endedOn = null;
        List<Step> steps = new ArrayList<>();
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. HH:mm:ss");

        for (int i = 0; i < attributes.getLength(); i++ ) {
            Node nod = attributes.item(i);
            if(nod.getNodeType() == Node.ELEMENT_NODE && !nod.getNodeName().contains("STEP")) {
                //System.out.println(nod.getNodeName() + ": " + nod.getTextContent());
                switch (nod.getNodeName()){
                    case "Device":
                        device = nod.getTextContent();
                        break;
                    case "SerialNr":
                        serialNr = nod.getTextContent();
                        break;
                    case "TotalResult":
                        totalResult = Integer.parseInt(nod.getTextContent());
                        break;
                    case "UserTester":
                        tester = nod.getTextContent();
                        break;
                    case "StartDate":
                        startedOn = ft.parse(nod.getTextContent());
                        break;
                    case "EndDate":
                        endedOn = ft.parse(nod.getTextContent());
                        break;
                }
            }

            if(nod.getNodeType() == Node.ELEMENT_NODE && nod.getNodeName().contains("STEP"))
                steps.add(getStepsFromNode(nod));
        }

        //Would be nicer with factory.
        return new TestResult(device, serialNr, totalResult, tester, startedOn, endedOn, steps);
    }

    /**
     * Loads steps from a node that contains a test result.
     *
     * @param nod node of a test result.
     * @return All steps for a single test result represented in a Step object.
     */
    private static Step getStepsFromNode(Node nod) {
        //System.out.println(nod.getChildNodes().item(2).getNodeName());
        Step step = new Step();
        for (int i = 0; i < nod.getChildNodes().getLength(); i++)
            if(nod.getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE)
                step.getStep().append(nod.getChildNodes().item(i).getNodeName() + ": " + nod.getChildNodes().item(i).getTextContent())
                        .append(System.lineSeparator());
        return step;
    }
}

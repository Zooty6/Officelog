package ReportFinder.Features;

import ReportFinder.GUI.MWController;
import ReportFinder.GUI.SerialsTableController;
import ReportFinder.Objects.TestResultForTable;
import ReportFinder.Settings.MetaData;
import javafx.application.Platform;

import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * Class for opening a file in KMPprfprt.
 *
 * @author Kecskeméthy Zoltán
 */
public class PDFOpener {

    /**
     * Don't let anyone instantiate this class.
     */
    private PDFOpener(){}

    /**
     * Opening report(s) for the parameter item. Parameter consist of Device number and Serial number.
     *
     * @param name String of the test item we are searching. Format: Device#SerialNr
     * @return True if report is found.
     */
    public static Boolean open(String name) {
        boolean found = false;
        name = name.replace('/', '%');
        String[] SplitName = name.split("#");
        if (SplitName.length == 2) {
            File pdfFolder = new File(MetaData.getInstance().getPDFLoc());
            if(!pdfFolder.exists())
                throw new NullPointerException("PDF folder was not found at " + MetaData.getInstance().getPDFLoc());
            File[] listOfFiles = pdfFolder.listFiles();

            //Checking all files..
            if(listOfFiles != null) {
                for (File file : listOfFiles) {
                    if (file.getName().contains(".pdf")) {
                        //MWController.instance.setTitle(Lang.getInstance().getString("Title") + " " + Lang.getInstance().getString("Loading") + dots[i++%3]);
                        //System.out.println(file.getName());
                        //Filtering files to open only what we are looking for.
                        if (file.getName().contains("$11" + SplitName[0])
                                && file.getName().contains("$12" + SplitName[1])) {
                            try {
                                Desktop.getDesktop().open(file);
                                found = true;
                            } catch (IOException e) {
                                System.err.println("couldn't open " + file.getName());
                            }
                        }
                    }
                }
            }else{
                System.err.println("PDF location does not exist!");
            }
        }
        //MWController.instance.setTitle(Lang.getInstance().getString("Title"));
        Platform.runLater(() -> MWController.instance.closeLoadingDialog());
        return found;
    }

    /**
     * Finds all PDF files for a given Device, and loads them to the caller window's list.
     *
     * @param device The device we are searching.
     * @param controller The controller of the window which contains the table of serials we want to populate with the results.
     */
    public static void find(String device, SerialsTableController controller) {
        device = device.replace('/', '%');
        device = device.replace('$', '%');
        File pdfFolder = new File(MetaData.getInstance().getPDFLoc());
        if (!pdfFolder.exists())
            throw new NullPointerException("PDF folder was not found at " + MetaData.getInstance().getPDFLoc());
        File[] listOfFiles = pdfFolder.listFiles();

        controller.loadingTitle();

        //Checking all files..
        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.getName().contains(".pdf") && file.getName().contains("$11")) {
                    //System.out.println(file.getName());
                    //Getting device name out from pdf name..
                    int i = 0;
                    while (!(file.getName().charAt(i) == '$' &&
                            file.getName().charAt(i + 1) == '1' &&
                            file.getName().charAt(i + 2) == '1')) {
                        i++;
                    }
                    String deviceInFileName = file.getName().substring(i, file.getName().length());
                    i = 1;
                    while (deviceInFileName.charAt(i) != '$')
                        i++;
                    deviceInFileName = deviceInFileName.substring(3, i);

                    //If it's what we are searching for..
                    if (deviceInFileName.contains(device)) {
                        i = 0;
                        while (!(file.getName().charAt(i) == '$' &&
                                file.getName().charAt(i + 1) == '1' &&
                                file.getName().charAt(i + 2) == '2')) {
                            i++;
                        }
                        String serialInFileName = file.getName().substring(i, file.getName().length());
                        i = 1;
                        while (serialInFileName.charAt(i) != '$')
                            i++;
                        serialInFileName = serialInFileName.substring(3, i);

                        //Give the found results to the controller.
                        //System.out.println(file.getPath());
                        controller.addTestResult(new TestResultForTable(
                                deviceInFileName.replace('%', '/'),
                                serialInFileName.replace('%', '/'),
                                file.getPath()));
                    }
                }
            }
            //System.out.println("END OF SEARCH");
            controller.resetTitle();
        }else{
            System.err.println("PDF location does not exist!");
        }
    }
}

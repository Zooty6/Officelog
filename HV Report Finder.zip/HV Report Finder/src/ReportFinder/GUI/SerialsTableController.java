package ReportFinder.GUI;

import ReportFinder.Features.PDFOpener;
import ReportFinder.Features.XMLReader;
import ReportFinder.Objects.TestResult;
import ReportFinder.Objects.TestResultForTable;
import ReportFinder.Settings.Lang;
import ReportFinder.Settings.MetaData;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

public class SerialsTableController implements Initializable{

    private static String name;
    private String title = Lang.getInstance().getString("Title") + " " + MetaData.VERSION + " (" + MWController.instance.getText().toUpperCase() + ')';
    public static Thread pdfThread;

    @FXML
    private TableView<TestResultForTable> tvSerials;
    @FXML
    private TableColumn<TestResultForTable, String> tcDevice;
    @FXML
    private TableColumn<TestResultForTable, String> tcTester;
    @FXML
    private TableColumn<TestResultForTable, String> tcDate;
    @FXML
    private TableColumn<TestResultForTable, String> tcSerial;
    @FXML
    private TableColumn<TestResultForTable, String> tcResult;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        name = MWController.instance.getText();
        name = name.replace('/','$');

        loadingTitle();
        tvSerials.setRowFactory( param -> {
            TableRow<TestResultForTable> row = new TableRow<TestResultForTable>(){
                private Tooltip tooltip = new Tooltip();

                @Override
                public void updateItem(TestResultForTable result, boolean empty) {
                    //Setting tooltip (hint message) for every row.
                    super.updateItem(result, empty);
                    if (result == null) {
                        setTooltip(null);
                    } else {
                        tooltip.setText(result.getDevice() + "#" + result.getSerialNr());
                        setTooltip(tooltip);
                    }
                }
            };
            //Mouse double click event on rows.
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
                    if (row.getItem().getPdfLoc() == null) {
                        TestResultForTable rowData = row.getItem();
                        MWController.instance.setText(rowData.getDevice() + "#" +
                                (rowData.getSerialNr().equals("") ? "#" : rowData.getSerialNr()));
                        tvSerials.getScene().getWindow().hide();
                    }else{
                        try {
                            Desktop.getDesktop().open(new File(row.getItem().getPdfLoc()));
                        } catch (IOException e) {
                            System.err.println("Can't open PDF at " + row.getItem().getPdfLoc());
                        }
                    }
                }
            });
            return row ;
        });

        tcDevice.setCellValueFactory(new PropertyValueFactory<>("device"));
        tcDevice.setText(Lang.getInstance().getString("DeviceString"));
        tcDevice.setSortType(TableColumn.SortType.DESCENDING);
        tcTester.setCellValueFactory(new PropertyValueFactory<>("tester"));
        tcTester.setText(Lang.getInstance().getString("TesterString"));
        tcDate.setCellValueFactory(new PropertyValueFactory<>("dateString"));
        tcDate.setText(Lang.getInstance().getString("DateString"));
        tcSerial.setCellValueFactory(new PropertyValueFactory<>("serialNr"));
        tcSerial.setText(Lang.getInstance().getString("SerialString"));
        tcResult.setCellValueFactory(new PropertyValueFactory<>("totalResult"));
        tcResult.setText(Lang.getInstance().getString("TotResultString"));
        tcResult.setCellFactory(getCustomCellFactory());
        File folder = new File(MetaData.getInstance().getXMLLoc());
        File[] listOfFiles = folder.listFiles();

        //Searching for files which need to be represented.

        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.getName().split("#")[0].contains(name.toUpperCase().split("#")[0])
                        && file.getName().contains("#")) {
                    try {
                        List<TestResult> results = XMLReader.loadTestResult(file.getName().split(".xml")[0]);
                        Collections.sort(results);
                        tvSerials.getItems().add(new TestResultForTable(results.get(results.size() - 1)));
                    } catch (XPathExpressionException | ParserConfigurationException | IOException | SAXException e) {
                        System.err.println("Couldn't open XML file. " + e.getMessage());
                    }
                }
            }
        }
        tvSerials.getSortOrder().add(tcDevice);
        if(MetaData.getInstance().isPdf()) {
            pdfThread = new Thread(() -> PDFOpener.find(name, this));
            pdfThread.start();
        }else{
            resetTitle();
        }

    }

    public void addTestResult(TestResultForTable testResult) {
        tvSerials.getItems().add(testResult);
    }

    private Callback<TableColumn<TestResultForTable, String>, TableCell<TestResultForTable, String>> getCustomCellFactory() {
        return (TableColumn<TestResultForTable, String> param) -> new TableCell<TestResultForTable, String>() {

            @Override
            public void updateItem(final String item, boolean empty) {
                if (item != null) {
                    if(!item.equals("0")) {
                        setText(item);
                        if(item.equals(Lang.getInstance().getString("Result1")))
                            setStyle("-fx-text-fill: green; -fx-font-weight: bold");

                        if(item.equals(Lang.getInstance().getString("Result2")))
                            setStyle("-fx-text-fill: red; -fx-font-weight: bold");
                    }else
                        setText("");
                }
            }
        };
    }

    public void resetTitle(){
        Platform.runLater(() -> ((Stage) (tvSerials.getScene().getWindow())).setTitle(title));
    }

    public void loadingTitle(){
        Platform.runLater(() -> ((Stage) (tvSerials.getScene().getWindow())).setTitle(title + " Loading.."));
    }
}

package ReportFinder.GUI;

import ReportFinder.Features.XMLReader;
import ReportFinder.Objects.TestResult;
import ReportFinder.Objects.TestResultForTable;
import ReportFinder.Settings.Lang;
import ReportFinder.Settings.MetaData;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SerialsTableController implements Initializable{

    private static String name;

    @FXML
    private TableView<TestResultForTable> tvSerials;
    @FXML
    private TableColumn<TestResultForTable, String> tcTester;
    @FXML
    private TableColumn<TestResultForTable, String> tcDate;
    @FXML
    private TableColumn<TestResultForTable, String> tcSerial;
    @FXML
    private TableColumn<TestResultForTable, String> tcResult;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        name = MWController.instance.getText();
        tvSerials.setRowFactory( param -> {
            TableRow<TestResultForTable> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
                    TestResultForTable rowData = row.getItem();
                    MWController.instance.setText(rowData.getDevice() + "#" + rowData.getSerialNr());
                    tvSerials.getScene().getWindow().hide();
                }
            });
            return row ;
        });
        tcTester.setCellValueFactory(new PropertyValueFactory<>("tester"));
        tcTester.setText(Lang.getInstance().getString("TesterString"));
        tcDate.setCellValueFactory(new PropertyValueFactory<>("dateString"));
        tcDate.setText(Lang.getInstance().getString("DateString"));
        tcSerial.setCellValueFactory(new PropertyValueFactory<>("serialNr"));
        tcSerial.setText(Lang.getInstance().getString("SerialString"));
        tcResult.setCellValueFactory(new PropertyValueFactory<>("totalResult"));
        tcResult.setText(Lang.getInstance().getString("TotResultString"));
        File folder = new File(MetaData.getInstance().getXMLLoc());
        File[] listOfFiles = folder.listFiles();
        try {
            for (File file : listOfFiles) {
                if(file.getName().startsWith(name)) {
                    List<TestResult> results = XMLReader.loadTestResult(file.getName().split(".xml")[0]);
                    tvSerials.getItems().add(new TestResultForTable(results.get(results.size() - 1)));
                }
            }
        } catch (XPathExpressionException | ParserConfigurationException | IOException | SAXException e) {
            System.err.println("Couldn't open XML file.");
        }
    }

    public static void setName(String name) {
        SerialsTableController.name = name;
    }


}

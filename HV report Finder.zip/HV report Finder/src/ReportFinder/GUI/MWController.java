package ReportFinder.GUI;

import ReportFinder.Features.PDFOpener;
import ReportFinder.Features.XMLReader;
import ReportFinder.Objects.Step;
import ReportFinder.Objects.TestResult;
import ReportFinder.Settings.Lang;
import ReportFinder.Settings.MetaData;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutionException;

public class MWController implements Initializable {
    public static MWController instance;
    private static Application.Parameters parameters;
    private Thread loadingThread;
    private Dialog<Void> aboutDialog;

    //<editor-fold desc="FXML Components">
    @FXML
    private AnchorPane apPane;
    @FXML
    private ChoiceBox<TestResult> cbReports;
    @FXML
    private Label lbCounter;
    @FXML
    private Label lbDeviceNumber;
    @FXML
    private Label lbSerial;
    @FXML
    private Label lbStartDate;
    @FXML
    private Button btnOk;
    @FXML
    private Button btnClear;
    @FXML
    private Label lbEndDate;
    @FXML
    private Label lbResult;
    @FXML
    private Label lbTester;
    @FXML
    private TextField tfSerial;
    @FXML
    private Rectangle rtBanner;
    @FXML
    private Rectangle rtBorder;
    @FXML
    private Label lbStart;
    @FXML
    private Label lbSerialNumber;
    @FXML
    private Label lbTesterName;
    @FXML
    private Label lbResultValue;
    @FXML
    private Label lbEnd;
    @FXML
    private Label lbDevice;
    @FXML
    private Label lbNotFound;
    @FXML
    private TextArea taSteps;
    @FXML
    private Menu meSelLang;
    @FXML
    private Menu meOptions;
    @FXML
    private RadioMenuItem rmPdf;
    @FXML
    private Menu meHelp;
    @FXML
    private MenuItem miMan;
    @FXML
    private MenuItem miAbout;
    @FXML
    private ImageView ivIcon;
    //</editor-fold>

    private Dialog<Void> dialog = new Dialog<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        instance = this;
        rmPdf.setSelected(MetaData.getInstance().isPdf());
        refreshLabels();
        populateLanguageMenu();
        setResultVisibility(false);
        //Adding listener for cbReports. Every time we select a new report, we load it.
        cbReports.getSelectionModel().selectedIndexProperty().addListener((observableValue, number, number2) ->{
            if (observableValue.getValue().intValue() > -1)
                displayReport(cbReports.getItems().get(observableValue.getValue().intValue()));});
        if (parameters.getRaw().size() == 1) {
            tfSerial.setText(parameters.getRaw().get(0));
            Platform.runLater(() -> {
                try {
                    instance.onBtnClick();
                } catch (ExecutionException | InterruptedException e) {
                    tfSerial.setText("");
                }
            });
        }
    }

    /**
     * Action of the Search button. Searches for a report with the given name or aborts the running search.
     */
    @FXML
    void onBtnClick() throws ExecutionException, InterruptedException {
        if (!dialog.isShowing()) { // if there is no search in progress..
            lbNotFound.setVisible(false);
            if (!tfSerial.getText().equals("")) {

                String nameOut = tfSerial.getText();
                //Cutting the '#' from the end of the name since the barcode reader might put it there.
                if (nameOut.charAt(nameOut.length() - 1) == '#')
                    nameOut = nameOut.substring(0, nameOut.length() - 1);
                int splitLength = nameOut.split("#").length;
                if (splitLength == 2) {
                    setResultVisibility(false);
                    loadingDialog();
                    loadingThread = new Thread(() -> {
                        List<TestResult> testResults;
                        String name = tfSerial.getText();
                        boolean xmlFound = false;

                        //Cutting the '#' from the end of the name since the barcode reader might put it there.
                        if (name.charAt(name.length() - 1) == '#')
                            name = name.substring(0, name.length() - 1);

                        try {
//                        int splitLength = name.split("#").length;
//                        if(splitLength == 2){

                            testResults = XMLReader.loadTestResult(name);
                            Platform.runLater(() -> displayReports(testResults));
                            xmlFound = true;
//                        }else if(splitLength == 1){
//                            testResults = XMLReader.loadSerials(name, FXMLLoader.load(getClass().getResource("SerialsTable.fxml")));
//                        }

                        } catch (XPathExpressionException | ParserConfigurationException | IOException | SAXException e) {
                            System.err.println("Couldn't open XML file.");
                        } finally {
                            Boolean pdfFound = false;
                            //We search for report(s) in KMPprfprt if the user selected rmPdf.
                            if (rmPdf.isSelected()) {
                                pdfFound = PDFOpener.open(name);
                            }
                            //Alerting user if no result is found.
                            if (!pdfFound && !xmlFound) {
                                Platform.runLater(() -> {
//                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                                alert.initOwner(apPane.getScene().getWindow());
//                                alert.setTitle(Lang.getInstance().getString("InfoTitle"));
//                                alert.setHeaderText(Lang.getInstance().getString("NoRepSubTitle"));
//                                alert.setContentText(Lang.getInstance().getString("NoRep") + ": " + tfSerial.getText());
//                                alert.showAndWait();
                                    lbNotFound.setText(Lang.getInstance().getString("NoRep") + ": " + tfSerial.getText());
                                    lbNotFound.setVisible(true);
                                });
                            }
                            Platform.runLater(() -> closeLoadingDialog());
                        }
                    });
                    loadingThread.start();
                }else if (splitLength == 1) {
                    try {
                        displayReports(XMLReader.loadSerials(nameOut, FXMLLoader.load(getClass().getResource("SerialsTable.fxml"))));
                    } catch (IOException e) {
                        System.err.println("Couldn't load SerialsTable.fxml");
                        e.printStackTrace();
                    }
                }
            }
            btnOk.setText(Lang.getInstance().getString("AbortStr"));
            tfSerial.requestFocus();
        }else{
            //Aborting the search..
            abortSearch();
        }
    }

    @FXML
    void onClear(){
        setResultVisibility(false);
        tfSerial.setText("");
        if(loadingThread.isAlive())
            abortSearch();
    }

    /**
     * Loads the selected language.
     *
     * @param event caller
     */
    void onLanguageLoad(ActionEvent event){
        Lang.getInstance().init("Lang\\"+((MenuItem) (event.getSource())).getText()+".lan");
        refreshLabels();
        meOptions.hide();
    }

    /**
     * Updates MetaData according to rmPdf.
     */
    @FXML
    void onPdfClick(){
        MetaData.getInstance().setPdf(rmPdf.isSelected());
    }

    /**
     * Every time we click on the menu bar, we load all the language files to it.
     */
    @FXML
    void onOptions() {
        populateLanguageMenu();
    }

    @FXML
    void onAbout(){
        if (aboutDialog == null) {
            //Init aboutDialog..
            aboutDialog = new Dialog<>();
            aboutDialog.initModality(Modality.NONE);
            aboutDialog.initOwner(apPane.getScene().getWindow());
            aboutDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK);
        }
        aboutDialog.setTitle(Lang.getInstance().getString("AboutString") + " HV Report Finder");
        aboutDialog.setContentText(Lang.getInstance().getString("AboutText1") + "\n" +
                Lang.getInstance().getString("AboutText2") + ": " + MetaData.VERSION + "\n\n" +
                (Lang.getInstance().getString("AboutText3") == null ? "" :
                        Lang.getInstance().getString("AboutText3")));
        aboutDialog.show();
    }

    @FXML
    void onOpenManual() {
        try {
            Desktop.getDesktop().open(new File("Manual\\Manual " + Lang.getInstance().getLoadedLanguage() + ".doc"));
            //TODO: Swap to PDF from DOC!
        } catch (IOException | IllegalArgumentException e) {
            try{
                //Second chance; loading default manual (English).
                Desktop.getDesktop().open(new File("Manual\\Manual En.PDF"));
            } catch (IOException | IllegalArgumentException e1) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initOwner(apPane.getScene().getWindow());
                alert.setTitle(Lang.getInstance().getString("ErrorTitle"));
                alert.setHeaderText(Lang.getInstance().getString(null));
                alert.setContentText(Lang.getInstance().getString("NoManErr"));
                alert.showAndWait();
            }
        }
    }

    /**
     * Sets every label on the GUI based on the loaded language.
     */
    private void refreshLabels() {
        btnOk.setText(Lang.getInstance().getString("SearchString"));
        btnClear.setText(Lang.getInstance().getString("ClearString"));
        lbDevice.setText(Lang.getInstance().getString("DeviceString") + ":");
        lbSerial.setText(Lang.getInstance().getString("SerialString") + ":");
        lbResult.setText(Lang.getInstance().getString("TotResultString") + ":");
        lbTester.setText(Lang.getInstance().getString("TesterString") + ":");
        lbStart.setText(Lang.getInstance().getString("StartString") + ":");
        lbEnd.setText(Lang.getInstance().getString("EndString") + ":");
        lbCounter.setText(Lang.getInstance().getString("CountString") + ": " + cbReports.getItems().size());
        meOptions.setText(Lang.getInstance().getString("OptionString"));
        meSelLang.setText(Lang.getInstance().getString("SelLangString"));
        rmPdf.setText(Lang.getInstance().getString("PDFString"));
        meHelp.setText(Lang.getInstance().getString("HelpString"));
        miMan.setText(Lang.getInstance().getString("ManString"));
        miAbout.setText(Lang.getInstance().getString("AboutString"));
        //Reloading the selected result for refreshing values.
        int index = cbReports.getSelectionModel().getSelectedIndex();
        cbReports.getSelectionModel().select(-1);
        cbReports.getSelectionModel().select(index);
        if(apPane.getScene() != null)
            ((Stage)(apPane.getScene().getWindow())).setTitle(Lang.getInstance().getString("Title")
                    + " " + MetaData.VERSION);
        if (lbNotFound.isVisible())
            lbNotFound.setText(Lang.getInstance().getString("NoRep") + ": " + tfSerial.getText());
    }

    /**
     * Displays a list of Test results on the GUI.
     *
     * @param testResults The list we want to display.
     */
    private void displayReports(List<TestResult> testResults){
        if(testResults != null) {
            //Sorting the collection by endDate. Oldest report is the first.
            Collections.sort(testResults);

            //Loading test results into cbReports.
            cbReports.setItems(FXCollections.observableArrayList(testResults));
            cbReports.getSelectionModel().selectLast();
            cbReports.setVisible(true);
            //Loading the most recent report. (Last one in the list.)
            displayReport(testResults.get(testResults.size() - 1));
            lbCounter.setText(Lang.getInstance().getString("CountString") + ": " + cbReports.getItems().size());
            //Giving the focus back the the text field.
            tfSerial.requestFocus();
        }
    }

    /**
     * Displays one report on the GUI.
     *
     * @param testResult the report we want to display.
     */
    private void displayReport(TestResult testResult) {

        //Feeding components with data..
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. hh:mm:ss");
        lbDeviceNumber.setText(testResult.getDevice());
        lbSerialNumber.setText(testResult.getSerialNr());
        // If we have a string for that result in the Lang file, we display that, else just the number.
        lbResultValue.setText(Lang.getInstance().getString("Result" + testResult.getTotalResult()) == null ?
                "" + testResult.getTotalResult() : Lang.getInstance().getString("Result" + testResult.getTotalResult()));
        // Coloring the result label
        switch (testResult.getTotalResult()) {
            case 1:
                lbResultValue.setTextFill(Color.valueOf("green"));
                break;
            case 2:
                lbResultValue.setTextFill(Color.valueOf("Red"));
                break;
            default:
                lbResultValue.setTextFill(Color.valueOf("black"));
                break;
        }
        lbTesterName.setText(testResult.getTester());
        lbStartDate.setText(ft.format(testResult.getStartedOn()));
        lbEndDate.setText(ft.format(testResult.getEndedOn()));
        taSteps.setText("");
        for (Step step : testResult.getSteps()) {
            taSteps.setText(taSteps.getText() + step.toString() + "--------------------------"
                    + System.lineSeparator() + System.lineSeparator());
        }

        //Making those components visible.
        setResultVisibility(true);
    }

    /**
     * Sets the visibility of all the components that used for displaying a test result.
     *
     * @param visibility Set true to make everything visible, false to hide everything.
     */
    private void setResultVisibility(boolean visibility){
        lbDevice.setVisible(visibility);
        lbDeviceNumber.setVisible(visibility);
        lbSerial.setVisible(visibility);
        lbSerialNumber.setVisible(visibility);
        lbResult.setVisible(visibility);
        lbResultValue.setVisible(visibility);
        lbTester.setVisible(visibility);
        lbTesterName.setVisible(visibility);
        lbStart.setVisible(visibility);
        lbStartDate.setVisible(visibility);
        lbEnd.setVisible(visibility);
        lbEndDate.setVisible(visibility);
        lbCounter.setVisible(visibility);
        taSteps.setVisible(visibility);
        cbReports.setVisible(visibility);
        rtBorder.setVisible(visibility);
        btnClear.setVisible(visibility);
    }

    /**
     * Stops the searching thread.
     */
    private void abortSearch() {
        loadingThread.stop(); //It might not release resources.. TODO: use running flag.
        if (dialog.isShowing())
            closeLoadingDialog();
        btnOk.setText(Lang.getInstance().getString("SearchString"));
    }

    /**
     * The "select language" menu item must be populated dynamically with the content of the Lang folder.
     * This method only cares about *.lan files, loads their names, and replaces the items in meSelLang.
     */
    private void populateLanguageMenu() {
        File LangFolder = new File("Lang");
        File[] listOfFiles = LangFolder.listFiles();
        if (listOfFiles.length > 0)
            //If we found something, we clear all items, and replace them with new ones.
            meSelLang.getItems().clear();
        for (int i = 0; i < listOfFiles.length; i++) {
            MenuItem languageFile = new MenuItem();
            //Trimming the extension of the file name.
            String filename = "";
            String[] nameParts = listOfFiles[i].getName().split("\\.");
            if(nameParts[nameParts.length-1].equals("lan")){  //We only care about .lan files.
                for (int i1 = 0; i1 < nameParts.length-1; i1++)
                    //We replace every dots, except the last one.
                    filename += i1 == nameParts.length - 2 ? nameParts[i1] : nameParts[i1] + '.';
                languageFile.setText(filename);
                languageFile.setOnAction((f) -> onLanguageLoad(f));
                meSelLang.getItems().add(languageFile);
            }
        }
    }

    /**
     * Displays a loading dialog.
     */
    private void loadingDialog(){
        //source: https://stackoverflow.com/questions/33457844/javafx-indeterminate-progress-dialog-overlay
        dialog = new Dialog<>();
        dialog.initModality(Modality.NONE);
        dialog.initOwner(apPane.getScene().getWindow());
        dialog.initStyle(StageStyle.TRANSPARENT);
        dialog.getDialogPane().setMaxWidth(72);
        dialog.getDialogPane().setMaxHeight(72);
        Label loader = new Label(Lang.getInstance().getString("Loading") == null ? "LOADING" :
                Lang.getInstance().getString("Loading"));
        loader.setContentDisplay(ContentDisplay.CENTER);
        loader.setGraphic(new ProgressIndicator());
        dialog.getDialogPane().setGraphic(loader);
        DropShadow ds = new DropShadow();
        ds.setOffsetX(1.3);
        ds.setOffsetY(1.3);
        ds.setColor(Color.DARKGRAY);
        dialog.getDialogPane().setEffect(ds);

        dialog.show();
        loadDialogRePoz();
    }

    /**
     * Closes the loading dialog.
     */
    public void closeLoadingDialog(){
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL);
        dialog.close();
        dialog.getDialogPane().getButtonTypes().clear();
        btnOk.setText(Lang.getInstance().getString("SearchString"));
    }

    /**
     * Resize the banner rectangle's width to parameter value.
     * It gets called every time the main scene is resized.
     *
     * @param width the new width of the banner.
     */
    public void resizeBanner(double width){
        rtBanner.setWidth(width);
    }

    /**
     * Sets the console arguments for the controller.
     */
    public static void setParameters(Application.Parameters parameters) {
        MWController.parameters = parameters;
    }

    /**
     * Relocate the loading dialog to the middle of the main window.
     */
    public void loadDialogRePoz() {
        if (dialog != null) {
            dialog.setX(apPane.getScene().getWindow().getX() + 95);
            dialog.setY(apPane.getScene().getWindow().getY() + 230);
        }
    }

    public Window getWindow() {
        return apPane.getScene().getWindow();
    }

    public String getText() {
        return tfSerial.getText();
    }

    public void setText(String text) {
        tfSerial.setText(text);
        try {
            onBtnClick();
        } catch (ExecutionException | InterruptedException e) {
            System.err.println("Couldn't open " + text);
        }
    }
}

package ReportFinder.Objects;

import ReportFinder.Settings.Lang;

import java.text.SimpleDateFormat;

public class TestResultForTable {
    String tester;
    String dateString;
    String serialNr;
    int totalResult;
    String device;

    public TestResultForTable() {
    }

    public TestResultForTable(String serialNr) {
        this.serialNr = serialNr;
        dateString = null;
        tester = null;
    }

    public TestResultForTable(TestResult tr){
        tester = tr.getTester();
        serialNr = tr.getSerialNr();
        totalResult = tr.getTotalResult();
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd. hh:mm:ss");
        dateString = ft.format(tr.getEndedOn());
        device = tr.getDevice();
    }

    public String getTester() {
        return tester;
    }

    public String getDateString() {
        return dateString;
    }

    public String getSerialNr() {
        return serialNr;
    }

    public String getDevice() {
        return device;
    }

    public String getTotalResult() {
        return Lang.getInstance().getString("Result" + totalResult) == null ?
                "" + totalResult : Lang.getInstance().getString("Result" + totalResult);
    }
}
